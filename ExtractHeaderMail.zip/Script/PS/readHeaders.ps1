Param
(
[Parameter(Mandatory=$true)] [string]$ProcessName,
[Parameter(Mandatory=$true)] [string]$SavePath
)
Get-ChildItem $SavePath -Filter *.msg |
ForEach-Object {
    $msg = ""
    $outlook = New-Object -comobject outlook.application
    $msg = $outlook.Session.OpenSharedItem($_.FullName)
    $msg | Select -ExpandProperty body 
	$headers = $msg.PropertyAccessor.GetProperty("http://schemas.microsoft.com/mapi/proptag/0x007D001E")

    return $headers
}